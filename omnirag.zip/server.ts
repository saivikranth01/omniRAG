import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import { createRequire } from "module";
import mammoth from "mammoth";
import multer from "multer";

// Use absolute path to avoid import.meta.url which fails in bundled CommonJS (.cjs)
const requireFn = createRequire(path.resolve("./server.ts"));
let pdfParseModule = requireFn("pdf-parse");
if (pdfParseModule.default) {
  pdfParseModule = pdfParseModule.default;
}
const PDFParse = pdfParseModule.PDFParse || pdfParseModule;

const app = express();
const PORT = 3000;

app.use(express.json());

// Persistent state directories
const DATA_DIR = path.resolve("./data");
const UPLOADS_DIR = path.join(DATA_DIR, "uploads");

// Create persistent directories if they don't exist
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true });

// DB File Paths
const DOCUMENTS_FILE = path.join(DATA_DIR, "documents.json");
const CHUNKS_FILE = path.join(DATA_DIR, "chunks.json");
const LOGS_FILE = path.join(DATA_DIR, "logs.json");
const CONFIG_FILE = path.join(DATA_DIR, "config.json");

// Multer Upload Setup
const storage = multer.memoryStorage();
const upload = multer({ storage });

// Helper functions for reading/writing DB
function readDbFile<T>(filePath: string, defaultValue: T): T {
  try {
    if (fs.existsSync(filePath)) {
      const content = fs.readFileSync(filePath, "utf-8");
      return JSON.parse(content) as T;
    }
  } catch (err) {
    console.error(`Error reading ${filePath}:`, err);
  }
  return defaultValue;
}

function writeDbFile<T>(filePath: string, data: T): void {
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), "utf-8");
  } catch (err) {
    console.error(`Error writing ${filePath}:`, err);
  }
}

// Lazy load Gemini Client to ensure we don't crash on startup if API key is missing
let aiInstance: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!aiInstance) {
    const apiKey = process.env.GOOGLE_API_KEY || process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("Missing Gemini API key! Please add GOOGLE_API_KEY or GEMINI_API_KEY under Settings > Secrets to enable RAG features.");
    }
    aiInstance = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiInstance;
}

// Slidining Window Chunking function (Word index-based)
function createSlidingWindowChunks(text: string, chunkSize = 150, overlap = 40): string[] {
  const words = text.trim().split(/\s+/);
  if (words.length === 0 || text.trim() === "") return [];

  const chunks: string[] = [];
  let start = 0;

  while (start < words.length) {
    const end = Math.min(start + chunkSize, words.length);
    const chunkWords = words.slice(start, end);
    chunks.push(chunkWords.join(" "));

    if (end === words.length) {
      break;
    }
    // Advance starting index based on chunk size and overlap
    start += (chunkSize - overlap);
  }

  return chunks;
}

// Direct rule and dictionary-based Named Entity Recognition (NER)
function extractNamedEntities(text: string): string[] {
  const entities: string[] = [];

  // Domain terms dictionaries
  const medicalRegex = /\b(Diabetes|Hypertension|Cardiology|Oncology|MRI|X-Ray|Metformin|Ibuprofen|Aspirin|Covid-19|Insulin|Asthma|Pneumonia|Flu|Statin|Cholesterol|Blood Pressure|Emergency|Therapy|Physician|Patient)\b/gi;
  const hrRegex = /\b(PTO|401k|Benefits|Medical Leave|Salary|Compensation|FMLA|Onboarding|KPI|W-2|I-9|Performance Review|Payroll|Retirement|Holiday|Recruitment|Workplace)\b/gi;
  const financeRegex = /\b(APR|Interest Rate|Checking Account|Savings Account|Mortgage|Collateral|Underwriting|Premium|Deductible|Actuary|Claim|Endorsement|Liability|Asset|Equity|Investment|Credit Score|Loan)\b/gi;
  const dateRegex = /\b(\d{4}-\d{2}-\d{2}|\d{2}\/\d{2}\/\d{4}|January|February|March|April|May|June|July|August|September|October|November|December)\s\d{1,2},?\s\d{4}\b/gi;
  const orgRegex = /\b([A-Z][a-zA-Z0-9]+ (Hospital|Clinic|Bank|Corp|Inc|LLC|Group|Association|Insurance|Solutions|Co))\b/g;

  let match;
  while ((match = medicalRegex.exec(text)) !== null) {
    entities.push(`MED: ${match[1]}`);
  }
  while ((match = hrRegex.exec(text)) !== null) {
    entities.push(`HR: ${match[1]}`);
  }
  while ((match = financeRegex.exec(text)) !== null) {
    entities.push(`FIN: ${match[1]}`);
  }
  while ((match = orgRegex.exec(text)) !== null) {
    entities.push(`ORG: ${match[1]}`);
  }
  while ((match = dateRegex.exec(text)) !== null) {
    entities.push(`DATE: ${match[0]}`);
  }

  // Proper nouns heuristic for general named terms
  const properNouns = text.match(/\b[A-Z][a-zA-Z]{3,}\b/g);
  if (properNouns) {
    properNouns.forEach((noun) => {
      const lower = noun.toLowerCase();
      const forbidden = ["healthcare", "insurance", "banking", "admin", "customer", "omnirag", "gemini", "agreement", "document", "provided", "herein", "within", "section"];
      if (!forbidden.includes(lower) && entities.length < 6 && !entities.some((e) => e.endsWith(noun))) {
        entities.push(`PROP: ${noun}`);
      }
    });
  }

  // Unique list of top 5 entities
  return Array.from(new Set(entities)).slice(0, 5);
}

// Cosine similarity index calculation
function cosineSimilarity(vecA: number[], vecB: number[]): number {
  let dotProduct = 0;
  let normA = 0;
  let normB = 0;
  for (let i = 0; i < vecA.length; i++) {
    dotProduct += vecA[i] * vecB[i];
    normA += vecA[i] * vecA[i];
    normB += vecB[i] * vecB[i];
  }
  if (normA === 0 || normB === 0) return 0;
  return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
}

// Type definitions for internal database
interface AppDocument {
  id: string;
  name: string;
  domain: string;
  size: number;
  wordCount: number;
  chunksCount: number;
  uploadedAt: string;
}

interface AppChunk {
  id: string;
  docId: string;
  docName: string;
  domain: string;
  text: string;
  embedding: number[];
  entities: string[];
}

interface QueryLog {
  id: string;
  timestamp: string;
  query: string;
  response: string;
  domain: string;
  matchedChunksCount: number;
  maxSimilarity: number;
  durationMs: number;
  isHallucinationGuarded: boolean;
  model: string;
  matchedChunks: {
    docName: string;
    text: string;
    similarity: number;
    entities: string[];
  }[];
}

interface AppConfig {
  model: string;
  similarityThreshold: number;
  temperature: number;
}

const DEFAULT_CONFIG: AppConfig = {
  model: "gemini-3.5-flash",
  similarityThreshold: 0.1,
  temperature: 0.2,
};

// --- API ENDPOINTS ---

// 1. LLM Configurations
app.get("/api/config", (req, res) => {
  const config = readDbFile<AppConfig>(CONFIG_FILE, DEFAULT_CONFIG);
  res.json(config);
});

app.post("/api/config", (req, res) => {
  const currentConfig = readDbFile<AppConfig>(CONFIG_FILE, DEFAULT_CONFIG);
  const newConfig = { ...currentConfig, ...req.body };
  writeDbFile(CONFIG_FILE, newConfig);
  res.json({ success: true, config: newConfig });
});

// 2. Document Ingestion Pipeline
app.post("/api/upload", upload.single("file"), async (req, res) => {
  try {
    const file = req.file;
    const domain = req.body.domain || "Healthcare";

    if (!file) {
      return res.status(400).json({ error: "No file was uploaded." });
    }

    // Authenticate Gemini SDK first (fail early if missing)
    const ai = getGeminiClient();

    // Extract text based on file format
    let text = "";
    const ext = file.originalname.split(".").pop()?.toLowerCase();

    if (ext === "txt") {
      text = file.buffer.toString("utf-8");
    } else if (ext === "pdf") {
      const parser = new PDFParse({ data: file.buffer });
      const data = await parser.getText();
      text = data.text || "";
      await parser.destroy().catch(() => {});
    } else if (ext === "docx") {
      const result = await mammoth.extractRawText({ buffer: file.buffer });
      text = result.value || "";
    } else {
      return res.status(400).json({ error: "Unsupported file extension. Please upload .pdf, .docx, or .txt files." });
    }

    if (!text.trim()) {
      return res.status(400).json({ error: "The document is empty or text could not be extracted." });
    }

    const wordCount = text.split(/\s+/).length;
    const rawChunks = createSlidingWindowChunks(text, 150, 40);

    if (rawChunks.length === 0) {
      return res.status(400).json({ error: "No text chunks generated. Is the document empty?" });
    }

    const docId = `doc-${Date.now()}`;
    const newDoc: AppDocument = {
      id: docId,
      name: file.originalname,
      domain,
      size: file.size,
      wordCount,
      chunksCount: rawChunks.length,
      uploadedAt: new Date().toISOString(),
    };

    const cachedDocs = readDbFile<AppDocument[]>(DOCUMENTS_FILE, []);
    const cachedChunks = readDbFile<AppChunk[]>(CHUNKS_FILE, []);

    // Obtain Real Gemini Embeddings for each chunk sequentially or in parallel
    const dbChunks: AppChunk[] = [];
    console.log(`Starting real Gemini embeddings generation for ${rawChunks.length} chunks...`);

    for (let i = 0; i < rawChunks.length; i++) {
      const chunkText = rawChunks[i];
      
      // Request gemini-embedding-001 reference embedding as explicitly demanded
      const embedResponse = await ai.models.embedContent({
        model: "gemini-embedding-001",
        contents: chunkText,
      });

      const embeddingValues = embedResponse.embeddings?.[0]?.values;
      if (!embeddingValues || embeddingValues.length === 0) {
        throw new Error(`Failed to generate embeddings value for chunk index ${i}`);
      }

      const entities = extractNamedEntities(chunkText);

      dbChunks.push({
        id: `${docId}-${i}`,
        docId,
        docName: file.originalname,
        domain,
        text: chunkText,
        embedding: embeddingValues,
        entities,
      });
    }

    // Persist Upload to databases
    cachedDocs.push(newDoc);
    cachedChunks.push(...dbChunks);

    writeDbFile(DOCUMENTS_FILE, cachedDocs);
    writeDbFile(CHUNKS_FILE, cachedChunks);

    return res.json({
      success: true,
      document: newDoc,
      chunksIngested: dbChunks.length,
    });
  } catch (err: any) {
    console.error("Document Ingestion error:", err);
    return res.status(500).json({ error: err.message || "An error occurred during file ingestion." });
  }
});

// Create sample system database if completely empty to bootstrap testing
app.post("/api/seed", async (req, res) => {
  try {
    const cachedDocs = readDbFile<AppDocument[]>(DOCUMENTS_FILE, []);
    if (cachedDocs.length > 0) {
      return res.json({ message: "Database already seeded", documentsCount: cachedDocs.length });
    }

    const ai = getGeminiClient();

    // Healthcare sample text
    const sampleText = `Medicare Guidelines for Cardiological Treatment (Health-Shield-Plus Corp 2026):
Under general oncology guidelines, chemotherapy and radiotherapy protocols are 100% matched under plan Medicare Schedule A.
However, patients with a documented history of chronic Hypertension require a specialized physician clearance prior to systemic treatments.
Metformin regimens for Type 2 Diabetes are covered under Formulary Class II with an annual co-pay limit of $150.
For emergency chest pain triage, patients are directed to our partner facility, California General Cardiology, where high-resolution MRI scans are authorized under standard copay limits.
Effective Date: March 15, 2026. Reviewer: Dr. Sarah Jenkins.`;

    const docId = "doc-seed-healthcare";
    const rawChunks = createSlidingWindowChunks(sampleText, 80, 20);
    const dbChunks: AppChunk[] = [];

    for (let i = 0; i < rawChunks.length; i++) {
        const chunkText = rawChunks[i];
        const embedResponse = await ai.models.embedContent({
          model: "gemini-embedding-001",
          contents: chunkText,
        });

        const embeddingValues = embedResponse.embeddings?.[0]?.values;
      if (embeddingValues) {
        dbChunks.push({
          id: `${docId}-${i}`,
          docId,
          docName: "Medicare_Healthcare_Directives.txt",
          domain: "Healthcare",
          text: chunkText,
          embedding: embeddingValues,
          entities: extractNamedEntities(chunkText),
        });
      }
    }

    const newDoc: AppDocument = {
      id: docId,
      name: "Medicare_Healthcare_Directives.txt",
      domain: "Healthcare",
      size: sampleText.length,
      wordCount: sampleText.split(/\s+/).length,
      chunksCount: dbChunks.length,
      uploadedAt: new Date().toISOString(),
    };

    cachedDocs.push(newDoc);
    writeDbFile(DOCUMENTS_FILE, cachedDocs);

    const cachedChunks = readDbFile<AppChunk[]>(CHUNKS_FILE, []);
    cachedChunks.push(...dbChunks);
    writeDbFile(CHUNKS_FILE, cachedChunks);

    return res.json({ success: true, seeded: true, document: newDoc });
  } catch (err: any) {
    console.error("Seeding failed:", err);
    return res.status(500).json({ error: err.message || "Seeding failed." });
  }
});

// 3. Documents Management Table
app.get("/api/documents", (req, res) => {
  const cachedDocs = readDbFile<AppDocument[]>(DOCUMENTS_FILE, []);
  res.json(cachedDocs);
});

app.delete("/api/documents/:id", (req, res) => {
  const docId = req.params.id;
  
  let cachedDocs = readDbFile<AppDocument[]>(DOCUMENTS_FILE, []);
  let cachedChunks = readDbFile<AppChunk[]>(CHUNKS_FILE, []);

  cachedDocs = cachedDocs.filter((d) => d.id !== docId);
  cachedChunks = cachedChunks.filter((c) => c.docId !== docId);

  writeDbFile(DOCUMENTS_FILE, cachedDocs);
  writeDbFile(CHUNKS_FILE, cachedChunks);

  res.json({ success: true });
});

// 4. Vector Store chunks search viewer
app.get("/api/vector-chunks", (req, res) => {
  const cachedChunks = readDbFile<AppChunk[]>(CHUNKS_FILE, []);
  const queryText = (req.query.q as string || "").trim().toLowerCase();

  const results = cachedChunks.map((c) => ({
    id: c.id,
    docName: c.docName,
    domain: c.domain,
    text: c.text,
    entities: c.entities,
  }));

  if (queryText === "") {
    res.json(results);
  } else {
    const filtered = results.filter(
      (c) => c.text.toLowerCase().includes(queryText) || c.docName.toLowerCase().includes(queryText) || c.domain.toLowerCase().includes(queryText)
    );
    res.json(filtered);
  }
});

// 5. Customer Portal multi-domain search & chat engine
app.post("/api/chat", async (req, res) => {
  const startTime = Date.now();
  try {
    const { messages, domain } = req.body; // domain is Healthcare, HR, Banking, Insurance, or Auto-Route
    if (!messages || messages.length === 0) {
      return res.status(400).json({ error: "No message query history provided." });
    }

    const latestMessageObj = messages[messages.length - 1];
    const userQueryText = latestMessageObj.content || latestMessageObj.text || "";

    if (!userQueryText.trim()) {
      return res.status(400).json({ error: "Empty query text supplied." });
    }

    // Read active LLM Configurations
    const currentConfig = readDbFile<AppConfig>(CONFIG_FILE, DEFAULT_CONFIG);
    const { model, similarityThreshold, temperature } = currentConfig;

    const ai = getGeminiClient();

    // a. Embed user query using gemini-embedding-001
    const embedResponse = await ai.models.embedContent({
      model: "gemini-embedding-001",
      contents: userQueryText,
    });

    const queryVec = embedResponse.embeddings?.[0]?.values;
    if (!queryVec) {
      throw new Error("Unable to create client search embedding.");
    }

    // b. Retrieve matching chunks from vector database
    const cachedChunks = readDbFile<AppChunk[]>(CHUNKS_FILE, []);
    
    // Auto-route domain classification logic if set to 'Auto-Route'
    let routedDomain = domain;
    if (domain === "Auto-Route") {
      // Small rule-based heuristic routing or standard match
      const lowerQuery = userQueryText.toLowerCase();
      if (lowerQuery.includes("hospital") || lowerQuery.includes("care") || lowerQuery.includes("medical") || lowerQuery.includes("hypertension") || lowerQuery.includes("diabetes") || lowerQuery.includes("heart") || lowerQuery.includes("doctor")) {
        routedDomain = "Healthcare";
      } else if (lowerQuery.includes("leave") || lowerQuery.includes("vacation") || lowerQuery.includes("hr") || lowerQuery.includes("pto") || lowerQuery.includes("benefits") || lowerQuery.includes("401k") || lowerQuery.includes("onboarding") || lowerQuery.includes("employee")) {
        routedDomain = "HR";
      } else if (lowerQuery.includes("mortgage") || lowerQuery.includes("apr") || lowerQuery.includes("interest") || lowerQuery.includes("savings") || lowerQuery.includes("credit") || lowerQuery.includes("banking") || lowerQuery.includes("loan") || lowerQuery.includes("checking")) {
        routedDomain = "Banking";
      } else if (lowerQuery.includes("premium") || lowerQuery.includes("deductible") || lowerQuery.includes("claim") || lowerQuery.includes("insurance") || lowerQuery.includes("liability") || lowerQuery.includes("policy") || lowerQuery.includes("underwrite")) {
        routedDomain = "Insurance";
      } else {
        // Fallback to highest similarity chunk domain if non-trivial chunk matches, else Healthcare
        routedDomain = "Healthcare";
      }
    }

    // Filter chunks by domain if NOT Auto-Route (or if routed, subsetting based on routed domain)
    // We can compute scores for ALL chunks first, then score-sorted routing
    const scoredChunks = cachedChunks.map((chunk) => {
      const sim = cosineSimilarity(queryVec, chunk.embedding);
      return { ...chunk, similarity: Number(sim.toFixed(4)) };
    });

    // If 'Auto-Route' we can look at the top scoring domain
    let finalDomain = routedDomain;
    if (domain === "Auto-Route" && scoredChunks.length > 0) {
      const topScored = [...scoredChunks].sort((a,b) => b.similarity - a.similarity)[0];
      if (topScored && topScored.similarity > 0.05) {
        finalDomain = topScored.domain;
      }
    }

    // Filter based on our target domain and user threshold
    const filteredByDomain = scoredChunks.filter((c) => c.domain === finalDomain);
    const sortedMatchedChunks = filteredByDomain
      .filter((c) => c.similarity >= similarityThreshold)
      .sort((a, b) => b.similarity - a.similarity)
      .slice(0, 5); // Take top 5 chunks

    const maxSimilarity = sortedMatchedChunks.length > 0 ? sortedMatchedChunks[0].similarity : 0;
    const isHallucinationGuarded = sortedMatchedChunks.length === 0;

    // c. Build the grounded context prompt
    let contextStr = "";
    if (!isHallucinationGuarded) {
      contextStr = sortedMatchedChunks
        .map((c, i) => `[Source Chunk #${i+1} from Document: "${c.docName}"]: \n${c.text}\nAssociated Entities: ${c.entities.join(", ")}`)
        .join("\n\n");
    }

    const systemPrompt = `You are OmniRAG, a premium and secure Multi-Domain Retrieval-Augmented Generation (RAG) assistant.
${isHallucinationGuarded ? "ANTI-HALLUCINATION GUARD IS ACTIVE: No high-matching source materials were found in the database for the selected domain description. You MUST state clearly that you have no verified context references and politely refuse to answer any specific claims that cannot be proven, instead of hallucinating facts." : "Answer the query using ONLY the provided verified document context materials below. Cite the source document names when explaining facts."}

Context information:
---------------------
${contextStr}
---------------------

Remember:
- Only reply using facts described in the Context contents.
- Do not make up facts or extrapolate. If not explicitly stated, politely decline to answer.
- Domain: ${finalDomain}.
- Current Model selected: ${model}.`;

    // Retrieve full chat history
    let contextMessagesStr = messages.slice(0, -1).map((m: any) => `${m.role === "user" ? "User" : "Assistant"}: ${m.content}`).join("\n");
    contextMessagesStr += `\nUser: ${userQueryText}`;

    // d. Execute chat response call to selected Gemini LLM
    const chatResponse = await ai.models.generateContent({
      model: model, // e.g. "gemini-3.5-flash" or "gemini-3.1-pro-preview"
      contents: contextMessagesStr,
      config: {
        systemInstruction: systemPrompt,
        temperature: temperature,
      },
    });

    const responseText = chatResponse.text || "I was unable to formulate a valid grounded response.";

    const durationMs = Date.now() - startTime;

    // Construct the structured response log object
    const finalMatchedChunksLog = sortedMatchedChunks.map((c) => ({
      docName: c.docName,
      text: c.text,
      similarity: c.similarity,
      entities: c.entities,
    }));

    const newLog: QueryLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      query: userQueryText,
      response: responseText,
      domain: finalDomain,
      matchedChunksCount: sortedMatchedChunks.length,
      maxSimilarity,
      durationMs,
      isHallucinationGuarded,
      model,
      matchedChunks: finalMatchedChunksLog,
    };

    const cachedLogs = readDbFile<QueryLog[]>(LOGS_FILE, []);
    cachedLogs.unshift(newLog); // push matching request to visual front of history
    writeDbFile(LOGS_FILE, cachedLogs);

    // Return search, citations, NER, and text safely to browser portal
    return res.json({
      role: "assistant",
      content: responseText,
      sources: finalMatchedChunksLog,
      isHallucinationGuarded,
      routedDomain: finalDomain,
      durationMs,
      timestamp: newLog.timestamp,
    });
  } catch (err: any) {
    console.error("Chat engine API error:", err);
    return res.status(500).json({ error: err.message || "An error occurred inside OmniRAG search engine." });
  }
});

// 6. Analytics dashboard distribution metrics
app.get("/api/analytics", (req, res) => {
  const cachedLogs = readDbFile<QueryLog[]>(LOGS_FILE, []);
  const cachedDocs = readDbFile<AppDocument[]>(DOCUMENTS_FILE, []);

  // Compute stats
  const totalQueries = cachedLogs.length;
  const avgDurationMs = totalQueries > 0
    ? Math.round(cachedLogs.reduce((acc, curr) => acc + curr.durationMs, 0) / totalQueries)
    : 0;

  const averageMaxSimilarity = totalQueries > 0
    ? Number((cachedLogs.reduce((acc, curr) => acc + curr.maxSimilarity, 0) / totalQueries).toFixed(3))
    : 0;

  // Domain queries counts distribution
  const domainDistribution = {
    Healthcare: 0,
    HR: 0,
    Banking: 0,
    Insurance: 0,
  };

  cachedLogs.forEach((log) => {
    const d = log.domain as keyof typeof domainDistribution;
    if (domainDistribution[d] !== undefined) {
      domainDistribution[d]++;
    }
  });

  // Active documents by domain
  const docCountByDomain = {
    Healthcare: 0,
    HR: 0,
    Banking: 0,
    Insurance: 0,
  };

  cachedDocs.forEach((doc) => {
    const d = doc.domain as keyof typeof docCountByDomain;
    if (docCountByDomain[d] !== undefined) {
      docCountByDomain[d]++;
    }
  });

  res.json({
    totalQueries,
    avgDurationMs,
    averageMaxSimilarity,
    domainQueries: domainDistribution,
    domainDocs: docCountByDomain,
    recentLogs: cachedLogs.slice(0, 30), // return top 30 logs
  });
});

// Configure development and production modes safely
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[OmniRAG] Full-stack Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
