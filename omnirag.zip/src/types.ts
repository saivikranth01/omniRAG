export interface AppDocument {
  id: string;
  name: string;
  domain: string;
  size: number;
  wordCount: number;
  chunksCount: number;
  uploadedAt: string;
}

export interface AppChunk {
  id: string;
  docId: string;
  docName: string;
  domain: string;
  text: string;
  entities: string[];
}

export interface QueryLog {
  id: string;
  timestamp: string;
  query: string;
  response: string;
  domain: string;
  matchedChunksCount: number;
  maxSimilarity: number;
  durationMs: number;
  isHallucinationGuarded: boolean;
  model: string;
  matchedChunks: {
    docName: string;
    text: string;
    similarity: number;
    entities: string[];
  }[];
}

export interface AppConfig {
  model: string;
  similarityThreshold: number;
  temperature: number;
}

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  sources?: {
    docName: string;
    text: string;
    similarity: number;
    entities: string[];
  }[];
  isHallucinationGuarded?: boolean;
  routedDomain?: string;
  durationMs?: number;
  timestamp?: string;
}
