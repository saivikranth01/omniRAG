import { useState, useEffect } from "react";
import { AppConfig } from "./types";
import { 
  Sparkles, 
  ShieldCheck, 
  Settings2, 
  Database, 
  User, 
  SlidersHorizontal, 
  AlertCircle 
} from "lucide-react";
import CustomerPortal from "./components/CustomerPortal";
import AdminPortal from "./components/AdminPortal";

const DEFAULT_CONFIG: AppConfig = {
  model: "gemini-3.5-flash",
  similarityThreshold: 0.1,
  temperature: 0.2,
};

export default function App() {
  const [activePortal, setActivePortal] = useState<"customer" | "admin">("customer");
  const [config, setConfig] = useState<AppConfig>(DEFAULT_CONFIG);
  const [loadingConfig, setLoadingConfig] = useState(true);
  const [errorText, setErrorText] = useState("");

  // Fetch configs from Express backend on mount
  const fetchConfig = async () => {
    try {
      const response = await fetch("/api/config");
      if (!response.ok) throw new Error("Could not fetch server configurations.");
      const data = await response.json();
      setConfig(data);
    } catch (err: any) {
      console.error(err);
      setErrorText("Check backend client configuration settings or environment variables.");
    } finally {
      setLoadingConfig(false);
    }
  };

  useEffect(() => {
    fetchConfig();
  }, []);

  return (
    <div className="min-h-screen bg-[#0A0A0B] text-white flex flex-col font-sans transition-colors duration-300">
      
      {/* Top Navigation Bar with monumental Bold Typography styling */}
      <header className="border-b border-white/10 p-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-[#0A0A0B]">
        <div className="flex flex-col">
          <h1 className="text-5xl sm:text-7xl font-black tracking-tighter leading-none italic uppercase text-white hover:opacity-90 transition-opacity">
            OmniRAG
          </h1>
          <span className="text-[10px] tracking-[0.3em] font-mono text-white/40 mt-1 uppercase">
            MULTI-DOMAIN RAG ARCHITECTURE / v3.5-FLASH
          </span>
        </div>

        {/* Tab/Portal Toggle Selectors styled as rounded-full design badges */}
        <div className="flex p-1 bg-white/[0.03] rounded-full border border-white/10 shrink-0 select-none">
          <button
            id="portal-toggle-customer"
            onClick={() => setActivePortal("customer")}
            className={`flex items-center gap-1.5 px-4 py-2 text-xs font-bold rounded-full transition-all duration-150 cursor-pointer uppercase tracking-wider ${
              activePortal === "customer"
                ? "bg-white text-black shadow-lg shadow-white/5 font-black"
                : "text-white/50 hover:text-white"
            }`}
          >
            <User className="w-3.5 h-3.5" />
            Customer Portal
          </button>
          <button
            id="portal-toggle-admin"
            onClick={() => setActivePortal("admin")}
            className={`flex items-center gap-1.5 px-4 py-2 text-xs font-bold rounded-full transition-all duration-150 cursor-pointer uppercase tracking-wider ${
              activePortal === "admin"
                ? "bg-white text-black shadow-lg shadow-white/5 font-black"
                : "text-white/50 hover:text-white"
            }`}
          >
            <Settings2 className="w-3.5 h-3.5" />
            Admin Portal
          </button>
        </div>
      </header>

      {/* Main Container Workspace */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        
        {/* Error warning notification alert banner */}
        {errorText && (
          <div className="bg-red-950/40 border border-red-500/30 text-red-200 p-4 rounded-xl text-xs flex items-center gap-3 shadow-md">
            <AlertCircle className="w-5 h-5 text-red-500 shrink-0" />
            <div>
              <span className="font-bold">System Configuration Interrupted:</span> {errorText} Ensure you set a valid <span className="font-mono">GEMINI_API_KEY</span> inside Settings &gt; Secrets in your workspace.
            </div>
          </div>
        )}

        {/* Real-time Config Status Dashboard Badges in the brand motif */}
        <div className="flex flex-wrap items-center justify-between gap-4 bg-white/[0.02] border border-white/10 p-4 rounded-xl">
          <div className="flex flex-wrap gap-4 items-center">
            <div className="text-white/40 text-[10px] uppercase font-black tracking-widest">
              Metrics Monitor:
            </div>
            <div className="flex items-center gap-1.5 text-xs text-white/80 bg-white/5 px-3 py-1.5 rounded-lg font-mono border border-white/10">
              <SlidersHorizontal className="w-3.5 h-3.5 text-white/40" /> Active Model: <span className="text-blue-400 font-bold">{config.model}</span>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-white/80 bg-white/5 px-3 py-1.5 rounded-lg font-mono border border-white/10">
              <ShieldCheck className="w-3.5 h-3.5 text-white/40" /> Threshold Limit: <span className="text-emerald-400 font-bold">{config.similarityThreshold}</span>
            </div>
          </div>
          <div className="hidden sm:block text-[10px] font-mono tracking-widest text-white/30 uppercase">
            Precision Cosine Grounding Enabled
          </div>
        </div>

        {/* Active View Portal Selector Router */}
        {loadingConfig ? (
          <div className="flex flex-col items-center justify-center p-24 text-white/40 text-xs gap-3">
            <Sparkles className="w-6 h-6 animate-spin text-white" />
            <span className="font-mono tracking-widest uppercase text-[10px]">Booting OmniRAG parameters...</span>
          </div>
        ) : activePortal === "customer" ? (
          <CustomerPortal config={config} />
        ) : (
          <AdminPortal config={config} onConfigChange={(newConfig) => setConfig(newConfig)} />
        )}
      </main>

      {/* Footer bar branding */}
      <footer className="border-t border-white/10 px-8 py-4 flex flex-col sm:flex-row justify-between items-center bg-black/40 text-[11px] text-white/40 select-none">
        <div className="max-w-7xl mx-auto w-full flex flex-col sm:flex-row items-center justify-between gap-3">
          <span className="font-mono uppercase tracking-wider">OmniRAG Knowledge Retrieval System &copy; 2026</span>
          <span className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span> 
            <span className="font-mono uppercase tracking-widest text-[10px]">Guard standards: strict zero-hallucination vector match.</span>
          </span>
        </div>
      </footer>

    </div>
  );
}
