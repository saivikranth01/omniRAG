import { useState, useEffect, useRef } from "react";
import { AppDocument, AppConfig } from "../types";
import { 
  Upload, 
  Trash2, 
  Database, 
  Cpu, 
  BarChart3, 
  FileText, 
  Search, 
  Settings, 
  RefreshCw, 
  AlertTriangle, 
  CheckCircle, 
  Server, 
  ArrowRight, 
  FolderLock, 
  Play 
} from "lucide-react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell 
} from "recharts";

interface AdminPortalProps {
  config: AppConfig;
  onConfigChange: (newConfig: AppConfig) => void;
}

const COLORS = ["#3b82f6", "#10b981", "#f59e0b", "#ef4444"];

export default function AdminPortal({ config, onConfigChange }: AdminPortalProps) {
  const [activeTab, setActiveTab] = useState<"ingestion" | "documents" | "vector" | "llm" | "analytics">("ingestion");
  const [documents, setDocuments] = useState<AppDocument[]>([]);
  const [isLoadingDocs, setIsLoadingDocs] = useState(false);

  // Ingestion Pipeline State
  const [selectedDomain, setSelectedDomain] = useState("Healthcare");
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [ingestStatus, setIngestStatus] = useState<{ type: "idle" | "success" | "error"; msg: string }>({ type: "idle", msg: "" });
  const [fileDragging, setFileDragging] = useState(false);

  // Seeding Pipeline State
  const [isSeeding, setIsSeeding] = useState(false);

  // Chunks store search state
  const [chunks, setChunks] = useState<any[]>([]);
  const [chunkQuery, setChunkQuery] = useState("");
  const [isLoadingChunks, setIsLoadingChunks] = useState(false);

  // LLM Config Form Local State
  const [formModel, setFormModel] = useState(config.model);
  const [formThreshold, setFormThreshold] = useState(config.similarityThreshold);
  const [formTemp, setFormTemp] = useState(config.temperature);
  const [saveConfigStatus, setSaveConfigStatus] = useState("");

  // Analytics Stats state
  const [analytics, setAnalytics] = useState<{
    totalQueries: number;
    avgDurationMs: number;
    averageMaxSimilarity: number;
    domainQueries: Record<string, number>;
    domainDocs: Record<string, number>;
    recentLogs: any[];
  }>({
    totalQueries: 0,
    avgDurationMs: 0,
    averageMaxSimilarity: 0,
    domainQueries: { Healthcare: 0, HR: 0, Banking: 0, Insurance: 0 },
    domainDocs: { Healthcare: 0, HR: 0, Banking: 0, Insurance: 0 },
    recentLogs: [],
  });
  const [isLoadingAnalytics, setIsLoadingAnalytics] = useState(false);

  // Fetch API Documents
  const loadDocuments = async () => {
    setIsLoadingDocs(true);
    try {
      const response = await fetch("/api/documents");
      const data = await response.json();
      setDocuments(data);
    } catch (err) {
      console.error("Failed to load documents:", err);
    } finally {
      setIsLoadingDocs(false);
    }
  };

  // Delete Document
  const handleDeleteDoc = async (docId: string) => {
    if (!window.confirm("Are you sure you want to delete this document and its associated vectors permanently?")) return;
    try {
      await fetch(`/api/documents/${docId}`, { method: "DELETE" });
      loadDocuments();
      loadChunks(); // refresh vector matches
      loadAnalytics(); // update dashboard numbers
    } catch (err) {
      console.error("Delete failure:", err);
    }
  };

  // Upload trigger pipeline
  const handleUploadFile = async () => {
    if (!uploadFile) return;
    setIsUploading(true);
    setIngestStatus({ type: "idle", msg: "" });

    const formData = new FormData();
    formData.append("file", uploadFile);
    formData.append("domain", selectedDomain);

    try {
      const res = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Execution failed.");
      }

      setIngestStatus({
        type: "success",
        msg: `Successfully parsed and ingested document: "${data.document.name}". Segmented into ${data.chunksIngested} sliding window chunks and stored embeddings in local vector index database.`,
      });
      setUploadFile(null);
      loadDocuments();
      loadChunks();
    } catch (err: any) {
      console.error(err);
      setIngestStatus({
        type: "error",
        msg: `Ingestion Failed: ${err.message || "Failed to parse document. Secure your API configuration."}`,
      });
    } finally {
      setIsUploading(false);
    }
  };

  // Bootstrapping seeded demo data
  const handleSeedDemodb = async () => {
    setIsSeeding(true);
    setIngestStatus({ type: "idle", msg: "" });
    try {
      const res = await fetch("/api/seed", { method: "POST" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Seed failed");

      setIngestStatus({
        type: "success",
        msg: data.seeded 
          ? `Sample database populated successfully! Ingested document Guideline "Medicare_Healthcare_Directives.txt" with real-time vector embeddings and healthcare medical entities.`
          : `Seed skipped: database indices already populated with documents.`,
      });
      loadDocuments();
      loadChunks();
      loadAnalytics();
    } catch (err: any) {
      console.error("Seeding failed", err);
      setIngestStatus({
        type: "error",
        msg: `Demo Database seed failed: ${err.message}`,
      });
    } finally {
      setIsSeeding(false);
    }
  };

  // Search inside vector-chunks
  const loadChunks = async () => {
    setIsLoadingChunks(true);
    try {
      const response = await fetch(`/api/vector-chunks?q=${encodeURIComponent(chunkQuery)}`);
      const data = await response.json();
      setChunks(data);
    } catch (err) {
      console.error("Failed to load chunks:", err);
    } finally {
      setIsLoadingChunks(false);
    }
  };

  // LLM Configurations Save handler
  const handleSaveConfig = async () => {
    try {
      const response = await fetch("/api/config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: formModel,
          similarityThreshold: formThreshold,
          temperature: formTemp,
        }),
      });

      if (!response.ok) throw new Error("Could not update configs.");
      const data = await response.json();
      onConfigChange(data.config);

      setSaveConfigStatus("Settings updated successfully!");
      setTimeout(() => setSaveConfigStatus(""), 3500);
    } catch (err: any) {
      console.error(err);
      setSaveConfigStatus("⚠️ System Config Updates Failed.");
    }
  };

  // Fetch metrics data logs
  const loadAnalytics = async () => {
    setIsLoadingAnalytics(true);
    try {
      const res = await fetch("/api/analytics");
      const data = await res.json();
      setAnalytics(data);
    } catch (err) {
      console.error("Load analytics failure:", err);
    } finally {
      setIsLoadingAnalytics(false);
    }
  };

  // Initial load inside admin hook transitions
  useEffect(() => {
    loadDocuments();
    loadChunks();
    loadAnalytics();
  }, []);

  useEffect(() => {
    if (activeTab === "analytics") {
      loadAnalytics();
    } else if (activeTab === "documents") {
      loadDocuments();
    } else if (activeTab === "vector") {
      loadChunks();
    }
  }, [activeTab]);

  // Analytics helper charts layout mapper
  const queryChartData = Object.entries(analytics.domainQueries).map(([name, value]) => ({ name, value }));
  const docChartData = Object.entries(analytics.domainDocs).map(([name, value]) => ({ name, value }));

  return (
    <div className="flex flex-col lg:flex-row gap-6 min-h-[600px] bg-white/[0.02] border border-white/10 rounded-2xl overflow-hidden shadow-xl">
      {/* Sidebar Navigation */}
      <div className="w-full lg:w-64 bg-[#0A0A0B] text-white p-5 flex flex-col justify-between shrink-0 border-r border-white/10 select-none">
        <div className="space-y-6">
          <div className="px-2">
            <span className="text-[10px] font-black text-white/30 uppercase tracking-[0.25em] block mb-1">Control Hub</span>
            <h3 className="text-sm font-black text-white tracking-widest uppercase italic">OmniRAG Admin</h3>
          </div>

          <nav className="space-y-1.5">
            <button
              id="admin-tab-ingestion"
              onClick={() => setActiveTab("ingestion")}
              className={`w-full flex items-center gap-3 px-4 py-3 text-xs font-bold rounded transition-colors cursor-pointer uppercase tracking-wider ${
                activeTab === "ingestion" ? "bg-white text-black font-black" : "hover:bg-white/5 text-white/50 hover:text-white"
              }`}
            >
              <Upload className="w-4 h-4 shrink-0" />
              Ingestion Pipeline
            </button>
            <button
              id="admin-tab-documents"
              onClick={() => setActiveTab("documents")}
              className={`w-full flex items-center gap-3 px-4 py-3 text-xs font-bold rounded transition-colors cursor-pointer uppercase tracking-wider ${
                activeTab === "documents" ? "bg-white text-black font-black" : "hover:bg-white/5 text-white/50 hover:text-white"
              }`}
            >
              <FileText className="w-4 h-4 shrink-0" />
              Ingested Documents ({documents.length})
            </button>
            <button
              id="admin-tab-vector"
              onClick={() => setActiveTab("vector")}
              className={`w-full flex items-center gap-3 px-4 py-3 text-xs font-bold rounded transition-colors cursor-pointer uppercase tracking-wider ${
                activeTab === "vector" ? "bg-white text-black font-black" : "hover:bg-white/5 text-white/50 hover:text-white"
              }`}
            >
              <Database className="w-4 h-4 shrink-0" />
              Vector Index Store
            </button>
            <button
              id="admin-tab-llm"
              onClick={() => setActiveTab("llm")}
              className={`w-full flex items-center gap-3 px-4 py-3 text-xs font-bold rounded transition-colors cursor-pointer uppercase tracking-wider ${
                activeTab === "llm" ? "bg-white text-black font-black" : "hover:bg-white/5 text-white/50 hover:text-white"
              }`}
            >
              <Cpu className="w-4 h-4 shrink-0" />
              LLM Config Solver
            </button>
            <button
              id="admin-tab-analytics"
              onClick={() => setActiveTab("analytics")}
              className={`w-full flex items-center gap-3 px-4 py-3 text-xs font-bold rounded transition-colors cursor-pointer uppercase tracking-wider ${
                activeTab === "analytics" ? "bg-white text-black font-black" : "hover:bg-white/5 text-white/50 hover:text-white"
              }`}
            >
              <BarChart3 className="w-4 h-4 shrink-0" />
              Analytics Dashboard
            </button>
          </nav>
        </div>

        {/* Node server status */}
        <div className="p-4 bg-white/[0.02] border border-white/10 rounded-xl text-xs space-y-1.5 mt-6 lg:mt-0">
          <div className="flex items-center justify-between">
            <span className="text-white/40 uppercase font-mono tracking-wider text-[10px]">Node backend:</span>
            <span className="flex items-center gap-1.5 text-[10px] text-emerald-400 font-extrabold uppercase font-mono">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span> Active
            </span>
          </div>
          <div className="text-[10px] text-white/30 font-mono truncate uppercase tracking-wide">
            Persistent storage online
          </div>
        </div>
      </div>

      {/* Main Panel Content */}
      <div className="flex-1 p-6 overflow-y-auto max-h-[750px] bg-transparent">
        
        {/* TAB 1: DOC INGESTION PIPELINE */}
        {activeTab === "ingestion" && (
          <div className="space-y-6" id="panel-ingestion">
            <div>
              <h2 className="text-xl font-black uppercase tracking-tight text-white">Doc Ingestion Pipeline</h2>
              <p className="text-xs text-white/40 font-mono tracking-wide mt-1">Upload new domain literature to partition it into vector embeddings leveraging our sliding window partitioner.</p>
            </div>

            {/* Config & Ingest Area */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 space-y-4">
                {/* Drag and Drop */}
                <div
                  onDragOver={(e) => { e.preventDefault(); setFileDragging(true); }}
                  onDragLeave={() => setFileDragging(false)}
                  onDrop={(e) => {
                    e.preventDefault();
                    setFileDragging(false);
                    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                      setUploadFile(e.dataTransfer.files[0]);
                    }
                  }}
                  className={`border-2 border-dashed rounded-xl p-8 flex flex-col items-center justify-center text-center cursor-pointer transition-colors ${
                    fileDragging 
                      ? "border-blue-500 bg-blue-950/20" 
                      : uploadFile 
                      ? "border-emerald-500 bg-emerald-950/10 text-emerald-300" 
                      : "border-white/10 bg-white/5 hover:border-white/20 hover:bg-white/[0.08]"
                  }`}
                  onClick={() => document.getElementById("file-picker")?.click()}
                >
                  <input
                    type="file"
                    id="file-picker"
                    accept=".pdf,.docx,.txt"
                    onChange={(e) => {
                      if (e.target.files && e.target.files[0]) {
                        setUploadFile(e.target.files[0]);
                      }
                    }}
                    className="hidden"
                  />
                  <Upload className={`w-10 h-10 mb-3 ${uploadFile ? "text-emerald-400" : "text-white/40"}`} />
                  {uploadFile ? (
                    <div>
                      <p className="text-sm font-bold text-emerald-400">{uploadFile.name}</p>
                      <p className="text-xs text-white/40 font-mono mt-1">{(uploadFile.size / 1024).toFixed(1)} KB • Ready for Ingestion</p>
                    </div>
                  ) : (
                    <div>
                      <p className="text-sm font-bold text-white/80">Drag & drop your files here, or <span className="underline text-white">browse</span></p>
                      <p className="text-xs text-white/30 font-mono mt-2 uppercase tracking-wider">Supports PDF, DOCX, TXT formats</p>
                    </div>
                  )}
                </div>

                {/* Status Logs */}
                {ingestStatus.type !== "idle" && (
                  <div className={`p-4 rounded-xl flex items-start gap-3 text-xs leading-relaxed ${
                    ingestStatus.type === "success" 
                      ? "bg-emerald-950/35 border border-emerald-500/30 text-emerald-200" 
                      : "bg-red-950/35 border border-red-500/30 text-red-200"
                  }`}>
                    {ingestStatus.type === "success" ? (
                      <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
                    ) : (
                      <AlertTriangle className="w-5 h-5 text-red-400 shrink-0" />
                    )}
                    <div>
                      <span className="font-bold uppercase tracking-wider text-[11px] block mb-1">{ingestStatus.type === "success" ? "Pipeline Completed:" : "Pipeline Interrupted:"}</span> 
                      {ingestStatus.msg}
                    </div>
                  </div>
                )}
              </div>

              {/* Side Parameters */}
              <div className="bg-white/[0.01] border border-white/10 rounded-xl p-5 h-fit space-y-4">
                <span className="text-[10px] font-black text-white/40 uppercase tracking-widest block">Ingestion Options</span>
                
                {/* Domain Selector */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-white/80 block">Destination Domain:</label>
                  <select
                    id="select-ingest-domain"
                    value={selectedDomain}
                    onChange={(e) => setSelectedDomain(e.target.value)}
                    className="w-full text-xs font-bold px-3 py-2.5 bg-black border border-white/10 hover:border-white/20 rounded-lg text-white cursor-pointer focus:outline-none"
                  >
                    {["Healthcare", "HR", "Banking", "Insurance"].map((d) => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                </div>

                {/* Chunking Details (Fixed/Informational as Requested) */}
                <div className="pt-3 border-t border-white/10 space-y-2 text-xs font-mono text-white/60">
                  <div className="flex justify-between">
                    <span className="text-white/40">Chunk partition:</span>
                    <span className="font-bold text-white">Sliding Window</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/40">Window limit:</span>
                    <span className="font-bold text-white">150 Words</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/40">Overlap limit:</span>
                    <span className="font-bold text-white">40 Words</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/40">Embed Model:</span>
                    <span className="text-blue-400 font-bold">gemini-embedding-001</span>
                  </div>
                </div>

                {/* Run Ingestion Action */}
                <button
                  id="btn-run-ingest"
                  onClick={handleUploadFile}
                  disabled={!uploadFile || isUploading}
                  className="w-full bg-white text-black hover:bg-white/90 disabled:opacity-30 disabled:hover:bg-white font-black py-2.5 rounded-lg text-xs uppercase tracking-wider transition duration-200 cursor-pointer flex items-center justify-center gap-1.5"
                >
                  {isUploading ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Embedding store...
                    </>
                  ) : (
                    <>Run Ingestion</>
                  )}
                </button>
              </div>
            </div>

            {/* Quick-Seed Helper */}
            <div className="p-5 bg-blue-950/20 border border-blue-500/30 rounded-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div>
                <h4 className="text-xs font-black tracking-wider text-blue-300 uppercase flex items-center gap-1.5">
                  <Server className="w-4 h-4" /> Bootstrap / Seed Database instantly
                </h4>
                <p className="text-[11px] text-blue-200/70 mt-1">Populate OmniRAG with our pre-built Medical Guidelines file to instantly test keying and similarities.</p>
              </div>
              <button
                id="btn-seed-db"
                onClick={handleSeedDemodb}
                disabled={isSeeding}
                className="bg-blue-600 hover:bg-blue-700 disabled:opacity-40 text-white font-bold flex items-center gap-1.5 px-4 py-2 text-xs rounded-lg transition shrink-0 cursor-pointer shadow-md uppercase tracking-wide"
              >
                {isSeeding ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Seeding...
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5" /> Seed Medical File
                  </>
                )}
              </button>
            </div>
          </div>
        )}

        {/* TAB 2: DOCUMENTS TABLE */}
        {activeTab === "documents" && (
          <div className="space-y-6" id="panel-documents">
            <div>
              <h2 className="text-xl font-black uppercase tracking-tight text-white font-sans">Ingested Index Documents</h2>
              <p className="text-xs text-white/40 font-mono tracking-wide mt-1">Manage vector grounded document indices currently persistent inside the RAG server.</p>
            </div>

            {isLoadingDocs ? (
              <div className="flex items-center justify-center p-12 text-white/40 text-xs gap-1.5 font-mono uppercase tracking-wider">
                <RefreshCw className="w-4 h-4 animate-spin text-white" /> Refreshing document grid...
              </div>
            ) : documents.length === 0 ? (
              <div className="p-8 border border-white/10 rounded-xl text-center bg-white/[0.01] text-white/40 text-xs space-y-2 font-mono uppercase tracking-wider">
                <p>No document files matched in storage.</p>
                <p className="text-[10px] text-white/20">Head over to the Ingestion Pipeline to upload vectors or test seeding.</p>
              </div>
            ) : (
              <div className="overflow-x-auto border border-white/10 rounded-xl bg-[#0A0A0B]">
                <table className="w-full text-left text-xs divide-y divide-white/10 min-w-[650px]">
                  <thead className="bg-white/[0.03] text-white/50 font-black uppercase tracking-widest text-[10px]">
                    <tr>
                      <th className="px-4 py-3">File Name</th>
                      <th className="px-4 py-3">Domain</th>
                      <th className="px-4 py-3 text-right">Size</th>
                      <th className="px-4 py-3 text-right">Words</th>
                      <th className="px-4 py-3 text-center">Chunks</th>
                      <th className="px-4 py-3">Ingested At</th>
                      <th className="px-4 py-3 text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/10 font-medium text-white/85 bg-transparent font-sans">
                    {documents.map((doc) => (
                      <tr key={doc.id} className="hover:bg-white/[0.02] transition">
                        <td className="px-4 py-3.5 truncate max-w-[200px] font-bold text-white">{doc.name}</td>
                        <td className="px-4 py-3.5">
                          <span className="px-2 py-0.5 bg-blue-950/40 border border-blue-500/30 text-blue-300 rounded font-bold text-[10px] uppercase font-mono tracking-wider">
                            {doc.domain}
                          </span>
                        </td>
                        <td className="px-4 py-3.5 text-right text-white/40 font-mono">{(doc.size / 1024).toFixed(1)} KB</td>
                        <td className="px-4 py-3.5 text-right font-mono text-white/40">{doc.wordCount}</td>
                        <td className="px-4 py-3.5 text-center font-bold text-white">{doc.chunksCount}</td>
                        <td className="px-4 py-3.5 text-white/30 font-mono text-[10px]">
                          {new Date(doc.uploadedAt).toLocaleString()}
                        </td>
                        <td className="px-4 py-3.5 text-center">
                          <button
                            id={`btn-del-doc-${doc.id}`}
                            onClick={() => handleDeleteDoc(doc.id)}
                            className="text-red-400 hover:text-red-300 bg-red-950/30 hover:bg-red-900/40 border border-red-500/20 p-2 rounded transition cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* TAB 3: VECTOR STORE VIEWER */}
        {activeTab === "vector" && (
          <div className="space-y-6" id="panel-vector-store">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-black uppercase tracking-tight text-white font-sans">Vector Chunk Explorer</h2>
                <p className="text-xs text-white/40 font-mono tracking-wide mt-1">Query and audit individual chunk partitions stored inside our embedded memory index.</p>
              </div>

              {/* Free format Search */}
              <div className="relative w-full md:w-72 shrink-0">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
                <input
                  type="text"
                  id="search-chunk-box"
                  value={chunkQuery}
                  onChange={(e) => setChunkQuery(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && loadChunks()}
                  placeholder="Keyword search in vectors..."
                  className="w-full text-xs pl-10 pr-4 py-3 bg-white/5 hover:bg-white/[0.08] border border-white/10 hover:border-white/20 focus:border-white focus:outline-none rounded-xl text-white placeholder-white/20 transition font-medium"
                />
              </div>
            </div>

            {isLoadingChunks ? (
              <div className="flex items-center justify-center p-12 text-white/40 text-xs gap-1.5 font-mono uppercase tracking-wider">
                <RefreshCw className="w-4 h-4 animate-spin text-white" /> Loading vector matching blocks...
              </div>
            ) : chunks.length === 0 ? (
              <div className="p-8 border border-white/10 rounded-xl text-center bg-white/[0.01] text-white/40 text-xs font-mono uppercase tracking-wider">
                No vector chunk partition meets filter settings. Add documents to search.
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-4">
                {chunks.map((chnk, blockIdx) => (
                  <div key={chnk.id || blockIdx} className="p-5 bg-white/[0.01] border border-white/10 hover:border-white/20 rounded-xl space-y-3.5 transition">
                    <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 pb-2.5">
                      <div className="flex items-center gap-1.5 truncate max-w-[70%]">
                        <FileText className="w-4 h-4 text-white/30 shrink-0" />
                        <span className="text-white/80 font-bold truncate text-sm">{chnk.docName}</span>
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0 font-mono">
                        <span className="text-[10px] bg-indigo-950 text-indigo-300 border border-indigo-500/30 px-2 py-0.5 rounded font-extrabold uppercase tracking-wider">
                          {chnk.domain}
                        </span>
                        <span className="text-[11px] text-white/30">
                          ID: {chnk.id}
                        </span>
                      </div>
                    </div>
                    <p className="text-white/80 font-sans text-xs italic leading-relaxed bg-white/[0.01] p-3 rounded-lg border-l-2 border-white/30">
                      "{chnk.text}"
                    </p>
                    {chnk.entities && chnk.entities.length > 0 && (
                      <div className="flex flex-wrap items-center gap-1.5 pt-1">
                        <span className="text-[10px] font-black uppercase tracking-widest text-white/30 mr-1.5 flex items-center gap-0.5">NER Tags:</span>
                        {chnk.entities.map((ent: string, idx: number) => (
                          <span
                            key={idx}
                            className="bg-white/5 text-white/75 border border-white/10 px-2 py-0.5 rounded-full text-[9px] font-semibold flex items-center gap-0.5"
                          >
                            {ent}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 4: LLM RESOLVER CONFIG */}
        {activeTab === "llm" && (
          <div className="space-y-6" id="panel-llm-settings">
            <div>
              <h2 className="text-xl font-black uppercase tracking-tight text-white font-sans">LLM Config Settings</h2>
              <p className="text-xs text-white/40 font-mono tracking-wide mt-1">Fine-tune the mathematical parameters and models evaluated during the RAG ground verification phases.</p>
            </div>

            <div className="max-w-xl bg-white/[0.01] border border-white/10 rounded-2xl p-6 space-y-6">
              
              {/* Model selection (Real ones matching constraint) */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-white/80 flex items-center justify-between">
                  <span>Target Generation model:</span>
                  <span className="text-[10px] text-emerald-400 uppercase font-extrabold tracking-widest bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-500/30">Active Model</span>
                </label>
                <select
                  id="select-llm-model"
                  value={formModel}
                  onChange={(e) => setFormModel(e.target.value)}
                  className="w-full text-xs font-bold px-3 py-3 bg-black border border-white/10 hover:border-white/20 rounded-xl focus:outline-none cursor-pointer text-white"
                >
                  <option value="gemini-3.5-flash">gemini-3.5-flash (Recommended standard RAG)</option>
                  <option value="gemini-3.1-pro-preview">gemini-3.1-pro-preview (High intelligence reasoning)</option>
                </select>
                <p className="text-[10px] text-white/40 leading-normal mt-1.5">Selected model processes grounded retrieval contexts. To comply with performance rules, ONLY standard valid Gemini models are indexed.</p>
              </div>

              {/* Similarity Slider */}
              <div className="space-y-3">
                <div className="flex justify-between text-xs font-bold text-white/80">
                  <span>Cosine Similarity Threshold:</span>
                  <span className="font-mono text-blue-400 font-bold text-sm">{formThreshold}</span>
                </div>
                <input
                  type="range"
                  id="slider-threshold"
                  min="0"
                  max="0.9"
                  step="0.05"
                  value={formThreshold}
                  onChange={(e) => setFormThreshold(parseFloat(e.target.value))}
                  className="w-full h-1 bg-white/15 rounded-lg appearance-none cursor-pointer accent-white"
                />
                <div className="flex justify-between text-[10px] text-white/30 uppercase font-mono font-bold tracking-wider">
                  <span>0.0 (Loose validation)</span>
                  <span>0.1 (Default threshold)</span>
                  <span>0.9 (Strict matching)</span>
                </div>
              </div>

              {/* Temperature Slider */}
              <div className="space-y-3">
                <div className="flex justify-between text-xs font-bold text-white/80">
                  <span>Generation Temperature:</span>
                  <span className="font-mono text-blue-400 font-bold text-sm">{formTemp}</span>
                </div>
                <input
                  type="range"
                  id="slider-temperature"
                  min="0"
                  max="1.0"
                  step="0.05"
                  value={formTemp}
                  onChange={(e) => setFormTemp(parseFloat(e.target.value))}
                  className="w-full h-1 bg-white/15 rounded-lg appearance-none cursor-pointer accent-white"
                />
                <div className="flex justify-between text-[10px] text-white/30 uppercase font-mono font-bold tracking-wider">
                  <span>0.0 (Deterministic)</span>
                  <span>1.0 (Creative output)</span>
                </div>
              </div>

              {/* Actions & Feedback */}
              <div className="pt-4 border-t border-white/10 flex items-center justify-between gap-4">
                <button
                  id="btn-save-llm-settings"
                  onClick={handleSaveConfig}
                  className="bg-white hover:bg-white/95 text-black font-black px-6 py-2.5 rounded-xl text-xs transition select-none cursor-pointer uppercase tracking-wider"
                >
                  Save Parameters
                </button>
                {saveConfigStatus && (
                  <span className="text-xs font-bold text-emerald-400 bg-emerald-950/40 px-3 py-1.5 rounded-lg border border-emerald-500/20">
                    {saveConfigStatus}
                  </span>
                )}
              </div>

            </div>
          </div>
        )}

        {/* TAB 5: ANALYTICS DASHBOARD */}
        {activeTab === "analytics" && (
          <div className="space-y-6" id="panel-analytics">
            <div>
              <h2 className="text-xl font-black uppercase tracking-tight text-white font-sans">System Analytics & Logs</h2>
              <p className="text-xs text-white/40 font-mono tracking-wide mt-1">Audit system queries, pipeline operational latencies, and search domain distribution maps.</p>
            </div>

            {/* Metrics Visual Panel Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-white/[0.01] border border-white/10 rounded-xl p-5 space-y-1.5 shadow-md">
                <span className="text-[10px] uppercase font-mono font-bold tracking-widest text-white/40">Total User Queries</span>
                <p className="text-3xl font-black text-white tracking-tight">{analytics.totalQueries}</p>
                <span className="text-[10px] text-white/20 uppercase font-mono block">Inbound searches logged</span>
              </div>
              <div className="bg-white/[0.01] border border-white/10 rounded-xl p-5 space-y-1.5 shadow-md">
                <span className="text-[10px] uppercase font-mono font-bold tracking-widest text-white/40">Average RAG Speed</span>
                <p className="text-3xl font-black text-white tracking-tight">{analytics.avgDurationMs}ms</p>
                <span className="text-[10px] text-white/20 uppercase font-mono block">Vector Match + LLM response</span>
              </div>
              <div className="bg-white/[0.01] border border-white/10 rounded-xl p-5 space-y-1.5 shadow-md">
                <span className="text-[10px] uppercase font-mono font-bold tracking-widest text-white/40">Average Similarity</span>
                <p className="text-3xl font-black text-white tracking-tight">{(analytics.averageMaxSimilarity * 100).toFixed(1)}%</p>
                <span className="text-[10px] text-white/20 uppercase font-mono block">Highest matching node score</span>
              </div>
            </div>

            {/* Ingestion Charts Row inside Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
              <div className="border border-white/10 rounded-xl p-5 bg-[#0D0D10] shadow-md">
                <span className="text-xs font-black uppercase tracking-widest text-[#9A9A9F] block mb-4">Query volume by Domain</span>
                <div className="h-56">
                  {analytics.totalQueries === 0 ? (
                    <div className="h-full flex items-center justify-center text-xs text-white/30 font-mono uppercase tracking-wider">
                      Submit a few query searches to view charts.
                    </div>
                  ) : (
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={queryChartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.05)" />
                        <XAxis dataKey="name" tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 10 }} stroke="rgba(255,255,255,0.1)" />
                        <YAxis tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 10 }} stroke="rgba(255,255,255,0.1)" />
                        <Tooltip contentStyle={{ fontSize: 11, borderRadius: 8, background: "#0D0D10", border: "1px solid rgba(255, 255, 255, 0.15)", color: "white" }} />
                        <Bar dataKey="value" fill="#ffffff" radius={[4, 4, 0, 0]}>
                          {queryChartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  )}
                </div>
              </div>

              <div className="border border-white/10 rounded-xl p-5 bg-[#0D0D10] shadow-md">
                <span className="text-xs font-black uppercase tracking-widest text-[#9A9A9F] block mb-4">Active Documents by Domain</span>
                <div className="h-56">
                  {documents.length === 0 ? (
                    <div className="h-full flex items-center justify-center text-xs text-white/30 font-mono uppercase tracking-wider">
                      Upload docs in Ingestion Pipeline to explore dataset charts.
                    </div>
                  ) : (
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={docChartData}
                          innerRadius={50}
                          outerRadius={80}
                          paddingAngle={5}
                          dataKey="value"
                        >
                          {docChartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip contentStyle={{ fontSize: 11, borderRadius: 8, background: "#0D0D10", border: "1px solid rgba(255, 255, 255, 0.15)", color: "white" }} />
                      </PieChart>
                    </ResponsiveContainer>
                  )}
                </div>
              </div>
            </div>

            {/* Query Audit Logging Ledger */}
            <div className="space-y-3 pt-2">
              <h3 className="text-xs font-black uppercase tracking-[0.2em] text-white/40">Query Logs Ledger</h3>
              {analytics.recentLogs.length === 0 ? (
                <div className="p-6 border border-white/10 text-center rounded-xl bg-white/[0.01] text-white/40 text-xs font-mono uppercase tracking-wider">
                  No query activities indexed so far.
                </div>
              ) : (
                <div className="space-y-3 max-h-[400px] overflow-y-auto pr-1">
                  {analytics.recentLogs.map((log) => (
                    <div key={log.id} className="p-5 bg-white/[0.01] border border-white/10 rounded-xl font-sans space-y-3.5">
                      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 pb-2.5">
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs font-bold text-white">Query: "{log.query}"</span>
                        </div>
                        <div className="flex items-center gap-2 font-mono text-[10px]">
                          <span className={`px-2 py-0.5 rounded font-extrabold uppercase tracking-wider text-[9px] ${log.isHallucinationGuarded ? "bg-amber-950 text-amber-300 border border-amber-500/20" : "bg-emerald-950 text-emerald-400 border border-emerald-500/20"}`}>
                            {log.isHallucinationGuarded ? "Guarded" : "Grounded"}
                          </span>
                          <span className="bg-white/5 border border-white/10 text-white/70 px-1.5 py-0.5 rounded font-bold uppercase">
                            {log.domain}
                          </span>
                          <span className="text-white/30">
                            {new Date(log.timestamp).toLocaleTimeString()}
                          </span>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                        <div className="md:col-span-2 space-y-1.5">
                          <span className="text-[10px] font-black uppercase tracking-widest text-[#9A9A9F]">OmniRAG Response</span>
                          <p className="text-white/80 text-xs leading-relaxed whitespace-pre-line bg-white/[0.02] p-3 rounded-lg border border-white/5 font-sans">{log.response}</p>
                        </div>
                        <div className="bg-white/[0.02] p-3 border border-white/5 rounded-lg space-y-2 h-fit text-[11px] text-white/70 font-mono">
                          <div className="flex justify-between">
                            <span className="text-white/40">Matching Speed:</span>
                            <span className="font-bold text-white">{log.durationMs}ms</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-white/40">Model Used:</span>
                            <span className="font-bold text-white">{log.model}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-white/40">Matched nodes:</span>
                            <span className="font-bold text-white">{log.matchedChunksCount}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-white/40">Score Value:</span>
                            <span className="font-bold text-white">{(log.maxSimilarity * 100).toFixed(1)}%</span>
                          </div>
                        </div>
                      </div>

                      {/* Cited matching chunks details */}
                      {log.matchedChunks && log.matchedChunks.length > 0 && (
                        <div className="bg-black/20 border border-white/5 rounded-lg p-3 text-[11px] space-y-2.5">
                          <span className="font-black uppercase tracking-widest text-white/30 block text-[9px]">Cited Document blocks:</span>
                          {log.matchedChunks.map((c: any, cidx: number) => (
                            <div key={cidx} className="border-l-2 border-white/20 pl-2.5 py-1 space-y-1 font-sans">
                              <div className="flex justify-between text-[10px] font-bold text-white/80">
                                <span className="truncate max-w-[70%]">{c.docName}</span>
                                <span className="font-mono text-emerald-400 font-bold">Similarity: {(c.similarity * 100).toFixed(1)}%</span>
                              </div>
                              <p className="text-white/60 italic">"{c.text}"</p>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>

          </div>
        )}

      </div>
    </div>
  );
}
