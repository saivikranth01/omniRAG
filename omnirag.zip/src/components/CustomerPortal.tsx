import React, { useState, useRef, useEffect } from "react";
import { Message, AppConfig } from "../types";
import { 
  Send, 
  Sparkles, 
  BookOpen, 
  ShieldAlert, 
  ShieldCheck, 
  HelpCircle, 
  ChevronDown, 
  ChevronUp, 
  CheckCircle2, 
  Clock, 
  Layers, 
  Tag 
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface CustomerPortalProps {
  config: AppConfig;
}

const SUGGESTIONS = [
  "Is cardiology covered under Medicare?",
  "What guidelines exist for oncology and oncology chemo protocols?",
  "Tell me about the Metformin copays and limits.",
  "Are there any specific guidelines for chronic Hypertension patients?"
];

export default function CustomerPortal({ config }: CustomerPortalProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      role: "assistant",
      content: "Hello! My name is OmniRAG. I can search our underlying Healthcare, Banking, HR, and Insurance document indices to answer your questions accurately inside the designated domain.",
    },
  ]);
  const [selectedDomain, setSelectedDomain] = useState<string>("Healthcare");
  const [inputValue, setInputValue] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [expandedSources, setExpandedSources] = useState<Record<string, boolean>>({});

  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isGenerating]);

  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim()) return;

    const userMsg: Message = {
      id: `msg-${Date.now()}`,
      role: "user",
      content: textToSend,
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputValue("");
    setIsGenerating(true);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [...messages, userMsg],
          domain: selectedDomain,
        }),
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || "Failed to fetch response.");
      }

      const botMsg: Message = await response.json();
      botMsg.id = `msg-${Date.now()}-bot`;
      setMessages((prev) => [...prev, botMsg]);
    } catch (err: any) {
      console.error("Chat error:", err);
      setMessages((prev) => [
        ...prev,
        {
          id: `msg-${Date.now()}-err`,
          role: "assistant",
          content: `⚠️ Error: ${err.message || "Failed to query OmniRAG system. Ensure your GEMINI_API_KEY is configured."}`,
        },
      ]);
    } finally {
      setIsGenerating(false);
    }
  };

  const toggleSources = (msgId: string) => {
    setExpandedSources((prev) => ({
      ...prev,
      [msgId]: !prev[msgId],
    }));
  };

  return (
    <div className="flex flex-col h-[calc(100vh-210px)] max-h-[750px] bg-white/[0.02] border border-white/10 rounded-2xl overflow-hidden">
      {/* Search Header Options */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-5 bg-white/[0.02] border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="bg-white text-black p-2.5 rounded-lg flex items-center justify-center">
            <Sparkles className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h2 className="text-sm font-black uppercase tracking-wider text-white">OmniRAG Search</h2>
            <p className="text-[10px] uppercase font-mono tracking-widest text-white/40">Retrieval-Augmented Grounding</p>
          </div>
        </div>

        {/* Domain Selection selector */}
        <div className="flex items-center gap-3">
          <label className="text-[10px] font-black uppercase tracking-widest text-white/40">Active Domain:</label>
          <div className="flex p-1 bg-white/[0.03] rounded-lg border border-white/10">
            {["Healthcare", "HR", "Banking", "Insurance", "Auto-Route"].map((dom) => (
              <button
                key={dom}
                id={`btn-dom-${dom}`}
                onClick={() => setSelectedDomain(dom)}
                className={`px-3 py-1.5 text-xs font-bold rounded transition-all duration-150 cursor-pointer ${
                  selectedDomain === dom
                    ? "bg-white text-black font-black uppercase"
                    : "text-white/50 hover:text-white uppercase font-bold"
                }`}
              >
                {dom}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Chat Messages Frame */}
      <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 bg-transparent">
        {messages.map((msg, i) => {
          const isUser = msg.role === "user";
          const showSources = msg.sources && msg.sources.length > 0;
          const isSourcesExpanded = expandedSources[msg.id];

          return (
            <div
              key={msg.id}
              className={`flex flex-col ${isUser ? "items-end" : "items-start"}`}
              id={`chat-item-${msg.id}`}
            >
              <div className="flex items-center gap-2 mb-1.5 px-1 text-white/40 text-[10px] font-mono uppercase tracking-wider">
                <span>{isUser ? "User Query" : "AI Response"}</span>
                <span>•</span>
                <span>{msg.timestamp ? new Date(msg.timestamp).toLocaleTimeString() : new Date().toLocaleTimeString()}</span>
                {!isUser && msg.routedDomain && (
                  <>
                    <span>•</span>
                    <span className="bg-blue-600 text-white font-bold px-1.5 py-0.5 rounded text-[10px] tracking-widest uppercase">
                      {msg.routedDomain}
                    </span>
                  </>
                )}
                {!isUser && msg.durationMs && (
                  <>
                    <span>•</span>
                    <span className="text-[10px] flex items-center gap-0.5 text-white/40 uppercase font-mono">
                      <Clock className="w-3 h-3" /> {msg.durationMs}ms
                    </span>
                  </>
                )}
              </div>

              {/* Message Content Bubble with premium typography and shapes */}
              <div
                className={`max-w-[85%] rounded-2xl p-5 text-sm leading-relaxed ${
                  isUser
                    ? "bg-white text-black font-semibold rounded-tr-none shadow-lg shadow-white/5"
                    : msg.isHallucinationGuarded
                    ? "bg-amber-950/25 text-amber-200 border border-amber-500/30 rounded-tl-none font-medium"
                    : "bg-white/5 text-white/90 border border-white/10 rounded-tl-none"
                }`}
              >
                {/* Text Content */}
                <span className="whitespace-pre-line text-base tracking-tight">{msg.content}</span>

                {/* Anti-Hallucination Guard Notification Alert */}
                {msg.isHallucinationGuarded && (
                  <div className="mt-3 pt-3 border-t border-amber-500/20 flex items-start gap-2 text-xs text-amber-300">
                    <ShieldAlert className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold uppercase tracking-wide text-xs">Anti-Hallucination Guard Active:</span> All database matching scores were below similarity threshold (<span className="font-mono text-emerald-400">{config.similarityThreshold}</span>). Outputs restricted strictly to avoid generating false guidelines.
                    </div>
                  </div>
                )}
              </div>

              {/* Collapsible Citations / Sources Panel */}
              {showSources && (
                <div className="mt-2 w-full max-w-[85%] bg-white/[0.02] border border-white/10 rounded-xl overflow-hidden">
                  <button
                    onClick={() => toggleSources(msg.id)}
                    className="w-full flex items-center justify-between px-4 py-3 text-xs font-bold text-white/70 hover:bg-white/10 transition-all duration-150 cursor-pointer"
                  >
                    <span className="flex items-center gap-1.5 uppercase font-mono tracking-wider">
                      <BookOpen className="w-3.5 h-3.5 text-blue-400" />
                      Grounded Sources ({msg.sources?.length} blocks)
                    </span>
                    <span className="flex items-center gap-2">
                      <span className="text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded font-extrabold uppercase tracking-widest">
                        Verified Match
                      </span>
                      {isSourcesExpanded ? <ChevronUp className="w-4 h-4 text-white/40" /> : <ChevronDown className="w-4 h-4" />}
                    </span>
                  </button>

                  <AnimatePresence>
                    {isSourcesExpanded && (
                      <motion.div
                        initial={{ height: 0 }}
                        animate={{ height: "auto" }}
                        exit={{ height: 0 }}
                        className="overflow-hidden border-t border-white/10"
                      >
                        <div className="p-3 space-y-3 bg-black/40 text-xs max-h-[250px] overflow-y-auto">
                           {msg.sources?.map((src, index) => (
                            <div key={index} className="p-3 bg-white/[0.02] border border-white/15 rounded-lg space-y-2">
                              <div className="flex items-center justify-between font-bold text-white">
                                <span className="flex items-center gap-1 shrink-0 max-w-[65%] truncate font-mono text-xs text-white/80">
                                  <Layers className="w-3 h-3 text-white/30 shrink-0" />
                                  {src.docName}
                                </span>
                                <span className="bg-emerald-950 text-emerald-400 border border-emerald-500/30 px-1.5 py-0.5 rounded text-[10px] font-mono whitespace-nowrap font-bold">
                                  Score: {(src.similarity * 100).toFixed(1)}%
                                </span>
                              </div>
                              <p className="italic text-white/70 leading-normal font-sans border-l-2 border-white/20 pl-2">
                                "{src.text}"
                              </p>
                              {src.entities && src.entities.length > 0 && (
                                <div className="flex flex-wrap items-center gap-1.5 pt-1">
                                  <span className="text-[10px] font-extrabold text-white/30 uppercase tracking-widest mr-1">
                                    Entities:
                                  </span>
                                  {src.entities.map((ent, idx) => (
                                    <span
                                      key={idx}
                                      className="px-1.5 py-0.5 bg-blue-950/40 border border-blue-500/20 rounded text-[9px] font-mono text-blue-300"
                                    >
                                      {ent}
                                    </span>
                                  ))}
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              )}
            </div>
          );
        })}

        {/* Loading / Generating State */}
        {isGenerating && (
          <div className="flex flex-col items-start">
            <div className="flex items-center gap-2 mb-1 px-1 text-white/40 text-[10px] font-mono uppercase tracking-widest">
              <span>OmniRAG</span>
              <span>•</span>
              <span className="italic text-emerald-400 animate-pulse">Running vector lookup...</span>
            </div>
            <div className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-2xl p-4 max-w-[80%]">
              <span className="w-2 h-2 bg-white rounded-full animate-bounce" style={{ animationDelay: "0ms" }}></span>
              <span className="w-2 h-2 bg-white rounded-full animate-bounce" style={{ animationDelay: "150ms" }}></span>
              <span className="w-2 h-2 bg-white rounded-full animate-bounce" style={{ animationDelay: "300ms" }}></span>
            </div>
          </div>
        )}
        <div ref={chatEndRef} />
      </div>

      {/* Query Suggestions Panel */}
      {messages.length < 3 && (
        <div className="p-4 bg-white/[0.01] border-t border-white/10 space-y-2">
          <p className="text-[10px] uppercase font-black tracking-[0.2em] text-white/40 flex items-center gap-1.5">
            <HelpCircle className="w-3.5 h-3.5 text-white/40" /> Recommended Grounded Enquiries
          </p>
          <div className="flex flex-wrap gap-2">
            {SUGGESTIONS.map((sug, idx) => (
              <button
                key={idx}
                id={`btn-sug-${idx}`}
                onClick={() => handleSendMessage(sug)}
                className="text-xs text-white/70 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 hover:border-white/20 rounded-lg px-3 py-2 text-left transition-colors duration-200 cursor-pointer font-medium"
              >
                {sug}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Chat Form Action Bar */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSendMessage(inputValue);
        }}
        className="flex items-center gap-3 p-4 bg-white/[0.02] border-t border-white/10"
      >
        <input
          type="text"
          id="chat-input-box"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          placeholder={`Enter query to grounded ${selectedDomain} index...`}
          disabled={isGenerating}
          className="flex-1 px-4 py-3 text-sm bg-white/5 border border-white/10 focus:outline-none focus:border-white focus:bg-white/[0.08] rounded-xl text-white placeholder-white/35 transition duration-200 disabled:opacity-50"
        />
        <button
          type="submit"
          id="chat-submit-button"
          disabled={isGenerating || !inputValue.trim()}
          className="bg-white hover:bg-white/90 disabled:opacity-30 disabled:hover:bg-white text-black p-3 rounded-xl flex items-center justify-center transition-all duration-200 cursor-pointer shadow-md"
        >
          <Send className="w-5 h-5" />
        </button>
      </form>
    </div>
  );
}
